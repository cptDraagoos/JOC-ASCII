#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#define _WIN32_WINNT 0x500
#include <MMsystem.h>
#include "desene.h"

int main()
{
        system("color 0C");
        char mainc[100];
        char z[1], NAME[25], clasa[25], weapon[100] , namew[25];
        int i , i2 , attack , j=0, us=50000;
        //PUNCTAJ
        int PUNCTE = 0;
        //CULOARE
        HANDLE hConsole;
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        //NAME
        titlu();
        sleep(3);
        system("cls || clear");
        meniu();

        printf("\t \t \t \t \t"); scanf("%s",&z);
        if(z[0]=='q')
        {
            exit(1);
        }
        system("color 0A");

        //LOADING INITIAL
        loading();
        sleep(4); system ("cls || clear");

        //TEXT INITIAL
        printf("\t \t \t \tPRESS 'F' TO BEGIN YOUR STORY..\n");
        scanf("                                 %s", &z);
        system ("cls || clear");
        slow_print("**FINALLY AFTER ALMOST 3 YEARS I'M CLOSE IN FINDING THE SUN STONE....**\nYOU:\nI CAN FINALLY BRING HER BACK\n",us);
        sleep(3);
        system ("cls || clear");

        //CULOARE RANDARE OBIECTE
        SetConsoleTextAttribute (hConsole, 8);
        munti1();
        //CULOARE TEXT
        system("color 0A");
        system ("cls || clear");
        slow_print("**YOU'RE CLOSE IN COMPLETING YOUR TASK SO YOU'RE APPROCHING THE DRAGON NEST**\n",us);
        slow_print("**THE ADRENALINE IS RUSHING THORW YOUR VEINS**",us);
        sleep(1);
        //DRAGON AWAKES
        system("cls || clear");
        slow_print("**SUDENLY A SOUND CAME FROM THE CAVE!!**",us);
        slow_print("\nUNKNOWN VOICE:\nWHO DARE'S WAKING ME UP?",us);
        slow_print("\nYOU:\nI THINK I KNOW WHO SAID THAT AND I DON'T LIKE IT..",us);
        sleep(2);
        system("cls || clear");
        slow_print("**THE EARTH STARTS SHAKING**",us);
        slow_print("\n**THE BEAST GOT HIS HEAD OUT THE CAVE**",us);
        sleep(2);
        system("cls || clear");
        SetConsoleTextAttribute (hConsole, 8);
        dragonhead();
        system("cls || clear");
        system("color 0A");
        slow_print("DRAGON:\nWHAT'S DOING A MORTAL LIKE YOU CLOSE TO MY CAVE?\nYOU CAME TO TAKE MY GOLD?\nOR HAVE YOU COME FOR MY SUN STONE MORTAL?",us);
        slow_print("\nYOU:\nGOD DAMN YOU'RE SCARY..",us);
        slow_print("\nDRAGON:\nTELL ME MORTAL...WHAT'S YOUR NAME?",us);
        sleep(2);
        system("cls || clear");
        printf("MY NAME IS: ");
        scanf("%s", &NAME);
        system("cls || clear");
        printf("DRAGON:\nHMM %s THAT'S AN INTRESTING NAME..\nBUT WHAT'S A MORTAL LIKE YOU DOIN HERE??", NAME);
        slow_print("\nYOU:\nI'M HERE TO TRY MY LUCK IN FINDING THE SUN STONE\n",us);
        slow_print("\nPAARTHANAX:\nVERY WELL WARRIOR,IM PAARTHANAX THE KEEPER OF THE STONE",us);
        slow_print("\nYOU:\nOH SO...DO YOU STILL HAVE IN YOUR POSESION?",us);
        slow_print("\nPAARTHANAX:\nOF COURSE I HAVE IT..\nNONE OF YOUR KIND WILL EVER GET THE STONE",us);
        slow_print("\nYOU:\nOK THEN...SO THIS IS THE WAY YOU WANT IT",us);
        sleep(3);
        system("cls || clear");
        //CLASA
        printf("CHOOSE YOUR CLASS %s\n",NAME);
        slow_print("THE CLASSES ARE:\n1-PALADIN-A HOLY KNIGTH TANKY EQUIPPED WITH A SWORD AND A SHIELD"
                               "\n2-BERSERKER-A NORSE WARRIOR EQUIPPED WITH A GIANT DOUBLE EGDE AXE AND RAGE"
                               "\n3-ASSASSIN-A DARK ELF FAR FROM HOME EQUIPPED WITH DOUBLE SWORDS AND VERY SNEAKY"
                               "\n4-MAGE-AN ELF FROM THE HOLY FOREST HAVING THE POWER OF THE NATURE MAGIK",us);
        slow_print("\nCHOOSE A NUMBER TO PICK YOUR CLASS AND THEN PRESS ENTER:",us);
        scanf("%d",&j);
        switch(j)
        {
        case 1:
                system("color 01");
                system("cls || clear");
                printf("YOUR CLASS IS NOW PALADIN");
                strcpy(clasa,"PALADIN");
                strcpy(weapon, ""
"    ()        \n"
"   __)(__      \n"
"   '-<>-'      \n"
"     )(   __   \n"
"     ||  / \\\  \n"
"     || (  ||) \n"
"     || ]_(\,| \n"
"     || ]-->/| \n"
"     || (  ||) \n"
"     ||  \\_//  \n"
"     ||        \n"
"     ||        \n"
"     \\/        \n");
                strcpy(namew,"SWORD n SHIELD");
                break;
            case 2:
                system("color 04");
                system("cls || clear");
                printf("YOUR CLASS IS NOW BERSERKER");
                strcpy(clasa,"BERSERKER");
                strcpy(weapon,""
"  ,:\      /:.  \n"
" //  \_()_/  \\\\ \n"
"||   |    |   ||\n"
"||   |    |   ||\n"
"||   |____|   ||\n"
" \\\  / || \\  // \n"
"  `:/  ||  \\;'  \n"
"       ||       \n"
"       ||       \n"
"       XX       \n"
"       XX       \n"
"       XX       \n"
"       XX       \n"
"       OO       \n");

                strcpy(namew,"BATTLE AXE");
                break;
            case 3:
                system("color 07");
                system("cls || clear");
                printf("YOUR CLASS IS NOW ASSASSIN");
                strcpy(clasa,"ASSASSIN");
                strcpy(weapon,""
"      O                                     O      \n"
"{o)xxx|================-  *  -===============|xxx(o}\n"
"      O                                     O      \n");
                strcpy(namew,"DOUBLE DEGGERS");
                break;
            case 4:
                system("color 03");
                system("cls || clear");
                printf("YOUR CLASS IS NOW MAGE");
                strcpy(clasa,"MAGE");
                strcpy(weapon,". *=====<<=)");
                strcpy(namew,"WAND");
                break;
        }
        sleep(1);
        system("cls || clear");
        system("color 0A");
        j=0;
        slow_print("NOW YOUNG MASTER WHAT YOU WANT TO DO:\n1-FIGTH THE DRAGON?\n2-TALK AND REASON WITH THE KEEPER OF THE STONE?\n3-RUN AWAY!",us);
        slow_print("\nSELECT ONE OF THE NUMBERS ABOVE FOR TAKING AN ACTION: ",us);
        scanf("%d",&j);
        sleep(3);
        system("cls || clear");
        if(j==1)
        {
            printf("YOU TAKE YOUR %s \n %s",namew , weapon);
            sleep(2);
            system("cls || clear");
            slow_print("PAARTHANAX:\nARE YOU SURE YOU REALLY WANNA DO THIS MORTAL?",us);
            sleep(2);
            system("cls || clear");
            slow_print("YOU:\nI HAVE NO CHOICE",us);
            sleep(3);
            system("cls || clear");
            slow_print("**YOU ATTACK THE DRAGON**\n**BUT YOUR ATTACK HAVE NO EFFECT ON HIM**\n**HE IS CHARCHING HIS FIRE BALL ATTACK",us);
            sleep(3);
            system("cls || clear");
            SetConsoleTextAttribute (hConsole, 8);
            dragonatt();
            sleep(4);
            system("cls || clear");
            system("color 0A");
            slow_print("**THE FIRE BALL HIT YOU FULL FORCE**",us);
            system("cls || clear");
            death();
            slow_print("\n \nPRESS 'F' TO CONTINUE\n \n",us);
            scanf("%s",&z);
        }
            else if(j==2)
            {
                slow_print("YOU:\nIM NOT HERE TO FIGTH WITH YOU.\nI KNOW I HAVE 0 CHANCES AGAINS SOMEONE LIKE YOU",us);
                slow_print("\nPAARTHANAX:\nYOU'RE SMARTER THAN OTHER OF YOUR RACE..\nTHAT'S PRETTY SURPRISING\nNOW TELL ME...WHY ARE YOU LOOKING FOR THE SUN STONE?",us);
                slow_print("\nYOU:\nI WANT TO TAKE REVENGE FOR MY LOVED ONE AND BRING HER BACK",us);
                slow_print("\nPAARTHANAX:\nARE YOU WILLING TO GIVE UP ON YOUR LIFE AND EVERYTHING TO DO THAT?",us);
                slow_print("\nYOU:\nEVERYTHING I DONE IN THESE LAST YEARS IS FOR HER...",us);
                slow_print("\nPAARTHANAX:\nYOU MORTALS AND ALL YOUR FEELINGS...",us);
                slow_print("\nYOU:\nIT IS WHAT IT IS AND I'M NOT BACKING DOWN NOW AFTER ALL I'VE BEEN THROUGH..I WILL NOT LET HER DOWN THIS TIME!",us);
                slow_print("\nPAARTHANAX:\nYOU'RE MAKIN ME LAUGH WITH ALL THESE NONE SENS OF YOURS",us);
                slow_print("\nYOU:\nYOU'RE A MONSTER AND THAT'S YOU'RE GONNA EVER BE!",us);
                slow_print("\nPAARTHANAX:\nAND THIS MONSTER WANTS YOU DEAD!!",us);
                sleep(1);
                system("cls || clear");
                slow_print("**THE DRAGON IS THROWING YOU MULTIPLE A FIRE BALLS**\n**ONE OF THEM HITTING YOU AND DOING MASSIVE DAMAGE**",us);
                sleep(1);
                SetConsoleTextAttribute (hConsole, 8);
                dragonatt();
                sleep(3);
                system("cls || clear");
                system("color 0A");
                slow_print("**YOU'RE BURNING AND THE LIFE FROM YOU IS SLOWLY FADING AWAY**",us);
                death();
                printf("\n \nPRESS 'F' TO CONTINUE\n \n");
                scanf("%s",&z);
            }
         else
         {
             slow_print("**YOU START SHAKING IN HIS PRESENCE SO YOU DECIDED TO RUN**",us);
             sleep(1);
             printf("\n"
                   "  /\\O  \n"
                   "   /\\/ \n"
                   "  /\\   \n"
                   " /  \\  \n"
                   "333  333");
            sleep(1);
            system("cls || clear");
            printf("\n"
                 "    _O   \n"
                 "   //|_  \n"
                 "    |    \n"
                 "   /|    \n"
                 "  3333   \n");
            sleep(1);
            system("cls || clear");
            printf("\n"
                   "   O  \n"
                   "  /_  \n"
                   "  |\\  \n"
                   "  / | \n"
                   "333333\n");
            sleep(1);
            system("cls || clear");
            slow_print("PAARTHANAX:\nWHERE DO YOU THINK YOU'RE GOING YOU LITTLE CREATURE?!\n**STARTS FLYING AFTER YOU**\n",us);
            sleep(1);
            SetConsoleTextAttribute (hConsole, 8);
            dragonzbr();
            sleep(3);
            system("cls || clear");
            system("color 0A");
            slow_print("YOU TRIED TO HIDE FROM IT BUT HE'S TO FAST AND START SHOOTING FIRE BALLS AT YOU",us);
            SetConsoleTextAttribute (hConsole, 8);
            dragonatt();
            sleep(1);
            death();
            printf("\n \nPRESS 'F' TO CONTINUE\n \n");
            scanf("%s",&z);
         }
        system("cls || clear");
        system("color 0A");
        slow_print("AELA:\nWAKE UP SILLY WE'RE GONNA BE LATE",us);
        slow_print("\nYOU:\nAELA?IS THAT YOU?\nHOW?\nWHAT?\nWHERE AM I?",us);
        slow_print("\nAELA:\nOF COURSE IS ME DUMMY.\nCOME GET UP, WE HAVE TO GO.",us);
        slow_print("\nYOU:\nWHERE ARE WE GOIN?\NWHAT'S HAPPENING?\nI SAW HIM KILL YOU!!",us);
        slow_print("\nAELA:\nI'M HERE SO NO ONE KILLED ME NOW GET DRESSED FASTER",us);
        slow_print("\nYOU:\nDID WE GET THE MAP?",us);
        slow_print("\nAELA:\nNO AND THAT'S WHY WE HAVE TO GO TAKE IT",us);
        slow_print("\nYOU:\nWHAT'S HAPPENING HERE?\n**THE DRAGON JUST KILLED ME...AELA SHOULD BE DEAD..HOW'S THIS HAPPENING?",us);
        sleep(2);
        system("cls || clear");
        slow_print("**THE CITY IS STILL WHOLE?**",us);
        SetConsoleTextAttribute (hConsole, 8);
        oras();
        sleep(2);
        system("cls || clear");
        system("color 0A");
        slow_print("\nYOU:\nAELA??\nWHAT DAY IS IT??",us);
        slow_print("\nAELA:\nIS JUST A DAY BEFORE SUMMER SOLSTICE\n*IT CAN'T BE..*\nYOU:\nAELA WE NEED TO RUN WE CAN'T GO!",us);
        slow_print("\nAELA:\nYEAH WE NEED TO RUN TO GO THAT MAP STOP FOOLING AROUND!\nYOU:\nI DON'T WANT TO LOSE YOU AGAIN STOP IT!",us);
        system("cls || clear");
        slow_print("AELA:\nI DONT UNDERSTAND WHAT YOU MEAN!\nYOU:\nI LIVED THIS BEFORE THIS IS NOT THE FIRST TIME THIS IS WHAT I'M SAYING!",us);
        slow_print("\nAELA:\nDO YOU REALISE HOW CRAZY DOES THIS SOUND?\nYOU:\nI KNOW BUT YOU HAVE TO TRUST ME!!THE TOWN IS GOIN BURN TO THE GROUND!",us);
        slow_print("\nAELA:\nOK JUST CALM DOWN TELL ME WHAT YOU WANT TO DO?\nYOU:\nFIRST WE NEED TO GET OUT OF THE TOWN CAUSE IT'S GONNA BE BURN TO THE GROUND",us);
        slow_print("\nAELA:\nWE CAN'T!!WE NEED TO SAVE THEM!\nYOU:\nWE DON'T HAVE TIME AND I DON'T WANT TO LOSE YOU AGAIN\nAELA:\nI WOULD RATHER DIE THAN RUN AND LET EVERYONE DIE",us);
        sleep(2);
        system("cls || clear");
        slow_print("**AELA TURNS HER BACK AT YOU AND HEADS TO THE TOWN HALL**",us);
        Aela();
        sleep(1);
        system("cls || clear");
        slow_print("WHAT ARE YOU GOIN TO DO?\n1.GO AFTER AELA AND HELP HER\n2.GO IN TO THE FOREST AND TRY TO STOP THE ATTACK THAT'S COMING FROM THE BARBERIANS ARMY",us);
        slow_print("\nCHOOSE A NUMBER FROM ABOVE TO TAKE YOUR ACTION\n",us);
        scanf("%d",&i);
        sleep(1);
        system("cls || clear");
        if(i==1)
        {
            PUNCTE+=10;
            slow_print("YOU:\nAELA WAIT!!I'M NOT LEAVING YOU ALONE\nAELA:\nI KNEW YOU WOULD LET ME DO THIS ON MY OWN",us);
            slow_print("\n**AELA TAKES YOUR HAND AND BOTH OF YOU ARE RUSHING TO THE TOWN HALL**",us);
            sleep(1);
            system("cls || clear");
            cityhall();
            sleep(1);
            system("cls || clear");
            slow_print("AELA:\n EVERYBODY LISTEN TO ME! WE NEED TO LEAVE THE CITY AS FAST AS WE CAN!\nRANDOM MAN:\nSHUT UP AELA! YOU JUST WANT TO STEAL FROM US LIKE ALWAYS!\nYOU:\nSHE WOULD NEVER DO SOMETHING LIKE THAT AND YOU WOULD BETTER LISTEN TO HER AND LEAVE THE CITY!\nRANDOM WOMAN:\nAND WHO ARE YOU? HER DOG?",us);
            sleep(1);
            system("cls || clear");
            slow_print("**FROM THE FOREST YOU CAN HEAR A SCREAM**\nYOU:\n OH NO..IT'S TO LATE! AELA RUN!",us);
            sleep(1);
            system("cls || clear");
            system("color 05");
            barbar();
            sleep(1);
            system("cls || clear");
            system("color 0A");
            slow_print("YOU:\nAELA IS TO LATE LET'S JUST LEAVE WE CAN STILL ESCAPE!!",us);
            printf("\nAELA:\nI CAN'T LEAVE THEM HERE TO DIE %s, WE NEED TO HELP THEM",NAME);
            slow_print("\n**WHAT ARE YOU GOIN TO DO?**\n 1:FIGTH WITH THE BARBARIANS AND HELP AELA\n 2:TAKE AELA AWAY BY FORCE",us);
            scanf("%d",&i2);
            system("cls || clear");
                    switch(i2){
                    case 1:
                        PUNCTE+=10;
                        slow_print("**YOU ARE ATTACKIN THE BARBERIANS AND HELPING AELA**\n **STILL THEY SET THE CITY ON FIRE AND STILL KILLS LOTS OF PEOPLE",us);
                        slow_print("YOU:\n PLEASE DON'T CRY AELA EVERYTHING IS GONNA BE FINE THIS WAS INEVITABLE\n AELA:\n HOW CAN YOU SAY THAT?\n YOU:\n ALL THAT MATTER IS THAT YOU ARE SAFE!",us);
                        system("cls || clear");
                        slow_print("YOU:\n WHAT SHOULD WE DO RIGTH NOW?\nAELA:YOU SAID SOMETHING ABOUT A DRAGON EARLIER..WHAT WAS THAT ABOUT\nYOU:\nI'M NOT SURE IF IT WAS A DREAM OR WHAT BUT I KNEW ALL OF THIS IS GONNA HAPPEN AND I FOUND WHERE THE SUN STONE IS",us);
                        slow_print("AELA:\n THAT'S WONDERFUL!!YOU NEED TO GET IT RIGTH AWAY!!\nYOU:\nTHAT'S EASIER TO SAY THEN IT IS TO DO\n AELA:\n BUT I BELIEVE IN YOU AND I KNOW YOU CAN DO IT!",us);
                        slow_print("YOU:\n AND WHAT ABOUT YOU?\nAELA:\n I NEED TO STAY HERE AND HELP EVERYBODY SO I KNOW THEY WILL BE SAFE\n BUT I KNOW YOU CAN GET THE STONE FOR US\nYOU:\n ANYTHING FOR YOU AELA",us);
                        system("cls || clear");
                        slow_print("**YOU KISSED AELA GOODBYE**",us);
                        system("color 07");
                        youaela();
                        sleep(1);
                        system("color 0A");
                        slow_print("**YOU START HEADING TO THE FOREST**",us);
                        system("color 02");
                        padure();
                        break;
                    case 2:
                        PUNCTE+=5;
                        system("color 0A");
                        slow_print("**YOU GRAB AELA BY HER WAIST AND RUN IN TO THE FOREST**",us);
                        system("color 02");
                        padure();
                        system("cls || clear");
                        system("color 0A");
                        slow_print("AELA:\nWHY DID YOU DO THAT????NOW EVERYBODY'S GONNA DIE AND IT'S ALL OUR FAULT!\nYOU:\nWE TRIED THEY DID NOT WANT TO LISTEN!\nAELA:\nTURN BACK NOW WE NEED TO SAVE THEM!\nYOU:\nWE CAN'T THE CITY IS ALREADY BURNING",us);
                        slow_print("\n**YOU LET GO OF AELA**\nYOU:THERE..WE SHOULD BE SAFE NOW\nAELA:\nWHAT HAPPEND TO YOU? YOU WERE A COWARD!\nYOU:\nI CAN'T LOSE YOU AGAIN DON'T YOU UNDERSANT?\nAELA:I WOULD RATHER DIE THAN DO SOMETHING LIKE THIS!",us);
                        slow_print("\n**AELA START WALKING AWAY FROM YOU**\nYOU:\nWHERE ARE YOU GOIN?\nAELA:\nAS FAR AWAY FROM YOU AS POSSIBLE\n**SHE SAID AS SHE'S GOING DEEPER IN THE FOREST",us);
                        slow_print("\nYOU:\nI NEED TO GO BE SURE SHE'S GONNA BE SAFE\n**THE FOREST IS TOO THICK AND YOU LOSE HER IN THE WOODS",us);
                        system("cls || clear");
                        break;
                    }
        }
        else if(i==2){
               PUNCTE+=1;
               slow_print("YOU:\nAELA WAIT!\nAELA:\nYES?\nYOU:\nCOME WITH ME LET'S STOP THEM BEFORE THEY GOT HERE\nAELA:\n GO ALONE I NEED TO HELP THE VILLIGERS\nYOU:\nJUST PROMISE ME TO BE CAREFUL\nAELA:\nI PROMISE, NOW GO!",us);
               slow_print("**YOU GRABBED YOUR WEAPON AND WENT IN TO THE FOREST**",us);
               sleep(1);
               system("cls || clear");
               system("color 02");
               padure();
               slow_print("**THE FOREST IS THICK BUT YOU KNOW THESE WOODS WELL**",us);
               sleep(1);
               system("cls || clear");
               system("color 0A");
               slow_print("WHAT IS YOUR PLAN IN STOPPING THE ATTACK\n 1:PREPARE A TRAP\n 2:FIGTH THEM HEAD ON \n",us);
               scanf("%d",&i2);
               system("cls || clear");
               switch(i2)
               {
                    case 1:
                        PUNCTE+=1;
                        slow_print("**YOU START DIGGING A WHOLE FOR A SPIKE TRAP**\n**SUDDENLY FROM A BUSH SOMETHING OR SOMEONE IS MAKING NOISES**",us);
                        system("color 02");
                        tufis();
                        sleep(1);
                        system("cls || clear");
                        system("color 03");
                        slow_print("**A MINOTAUR IS ATTACKING YOU**",us);
                        minotaur();
                        sleep(1);
                        system("cls || clear");
                        system("color 0A");
                        slow_print("**HE'S TRYING TO SLASH YOU WITH HIS SWORD**\n**YOU'RE DODGING EVERY SINGLE ATTACK OF HIS**\n**YOU COUNTER ATTACK HIM AND KILL HIM**\n**BUT IS TO LATE THE ARMY ALREADY ENTER THE CITY AND BURN IT TO THE GROUND**\n**IN THE PROCCESS THEY KILL AELA TOO**",us);
                        system("cls || clear");
                        slow_print("**YOU BURST IN TO TEARS BUT NOW YOU REALISE WHAT YOU NEED TO DO**\n**YOU NEED TO GET THE SUN STONE SO YOU CAN BRING AELA BACK**",us);
                        break;
                    case 2:
                        PUNCTE+=1;
                        slow_print("**YOU DECIDED TO TAKE THE ARMY HEAD ON**\n**YOU TRIED STOPPING THEM BUT THEY ARE TO MANY SO YOU RETREAT TO HEAL YOURS WOUNDS**\n**THE BARBERIANS ARE NOT STOPPING AND THEY KEEP GOING AND DESTROY THE VILLAGE AND KILL EVERYBODY IN THE CITY**\n**INCLUDING AELA**",us);
                        system("cls || clear");
                        slow_print("**YOU BURST IN TO TEARS BUT NOW YOU REALISE WHAT YOU NEED TO DO**\n**YOU NEED TO GET THE SUN STONE SO YOU CAN BRING AELA BACK**",us);
                        break;
               }
        }
        sleep(1);
        system("cls || clear");
        slow_print("**THERE ONLY ONE GOAL IN YOUR MIND AND THAT IS TO GET THE SUN STONE***\n**YOU ALREADY KNOW THE LOCATION OF THE STONE SO THIS WILL MAKE YOUR JOURNEY EASIER**",us);
        slow_print("\n**THERE ARE 2 WAY TO GET TO THE KILIMANJARO MOUTAINS**\n**1:THROUGH THE SNOWIE TUNDRA**\n**2:THE SUNNY VALLEY**\n**BUT DON'T GET FOUL BY THEIR NAMES**\n",us);
        scanf("%d",&i);
        sleep(1);
        system("cls || clear");
        if(i==1)
        {
            PUNCTE+=10;
            slow_print("**IN DESPITE OF THE COLD AND THE WIND IN THE TUNDRA YOU WILL HAVE A CALM JOURNEY ON A HORSEBACK**",us);
            system("cls || clear");
            d3();
            sleep(1);
            system("cls || clear");
            slow_print("**IN A PIT STOP SOMETHING CAUGTH YOUR ATTENTION A LITTLE DOGGY COMES CLOSE TO YOU**\n**WILL YOU GIVE HIM SOME FOOD?**\n1:YES!\n2:NO!\n",us);
            scanf("%d",&i2);
            if(i2==1)
            {
                PUNCTE=+10;
                slow_print("**THE DOG IS NOW JOINING YOUR TRIP**",us);
                doggy();
            }
            else{
                PUNCTE+=1;
                slow_print("**YOU DID NOT WANT TO FEED HIM**",us);
                sad();
            }
        }
        else{
            PUNCTE+=1;
            slow_print("**THIS IS GONNA BE A ROUGTH JOURNEY FOR YOU CAUSE IS FULL OF POISONS PLANTS AND ORCS**",us);
            system("cls || clear");
            d3();
            sleep(1);
            system("cls || clear");
            slow_print("**IN A PIT STOP SOMETHING CAUGTH YOUR ATTENTION A LITTLE DOGGY COMES CLOSE TO YOU**\n**WILL YOU GIVE HIM SOME FOOD?**\n1:YES!\n2:NO!\n",us);
            scanf("%d",&i2);
            if(i2==1)
            {
                PUNCTE=+5;
                slow_print("**THE DOG IS NOW JOINING YOUR TRIP**",us);
                doggy();
            }
            else
            {
                PUNCTE+=1;
                slow_print("**YOU DID NOT WANT TO FEED HIM**",us);
                sad();
            }
        }
        sleep(1);
        system("cls || clear");
        d4();
        slow_print("**THE MOUNTAINS IS JUST IN FRONT OF YOU**",us);
        munti1();
        sleep(1);
        system("cls || clear");
        system("color 0A");
        //goodending
        if(PUNCTE > 20)
        {
            finishstart();
            dragonhead();
            sleep(1);
            system("cls || clear");
            finish2();
            slow_print("YOU:\nTHIS CAN'T BE REAL..THAT MEANS SHE IS GONE? NOTHING WAS REALLY REAL??NO,THIS WILL NOT BE THE END\nPAARTHANAX:\nTHIS IS THE END FOR YOU!",us);
            dragonatt();
            sleep(1);
            system("cls || clear");
            slow_print("**YOU BLOCK THE DRAGON ATTACK,COUNTER ATTACKING HIM AND DOING HIM DAMAGE**\nPAARTHANAX:\nHOW DARE YOU MORTAL? YOU WILL DIE FOR DOING THIS!",us);
            SetConsoleTextAttribute (hConsole, 8);
            dragonmad();
            sleep(1);
            system("cls || clear");
            system("color 0A");
            slow_print("**YOU GRABED YOUR WEAPON AND HELPED BY THE POWER YOU GATHER IN THIS PUGATORY YOU STIKE THE DRAGON RIGTH IN THE FOREHEAD KILLING HIM**",us);
            slow_print("\nPAARTHANX:\nNOOO THIS CAN'T BEE!!!I AM THE MUGTHY PAARTHANAX THE KEEPER OF THE STONE I CANNOT be kill....",us);
            slow_print("**YOU GATHER YOUR POWER AND GO TO GRAB THE SUNSTONE FROM THE TREASURE OF THE DRAGON**",us);
            sunstone();
            slow_print("**YOU CAN ESCAPE THE PURGATORY AND BE REUNITED WITH AELA**",us);
            sleep(1);
            system("cls || clear");
            end1();
            titlu();
            sleep(2);
        }
        //bravomaaiterminatsituasa
        else if(PUNCTE >15 && PUNCTE < 20)
        {
            finishstart();
            dragonhead();
            sleep(1);
            system("cls || clear");
            finish2();
            slow_print("YOU:\nDOES THIS MEAN SHE IS GONE FOREVER?\nPAARTHANAX:\nSHE IS GONE AND NOW YOU'RE NEXT!",us);
            SetConsoleTextAttribute (hConsole, 8);
            dragonmad();
            sleep(1);
            system("cls || clear");
            system("color 0A");
            slow_print("**THE DRAGON ATTACKS YOU BUT YOU BLOCK HIS ATTACK SUCCESFULLY**\n**YOU SLIDE UNDER HIS BELLY AND GRAB THE SUN STONE**\n**PAARTHANAX CUTS YOUR HANDS OFF AND STOP YOU FROM ESCAPING THE PURGATORY**\n**YOU'RE GONNA BE BLOCK AND BE FORCE TO LIVE  EVERYTHING OVER AND OVER AGAIN",us);
            sleep(1);
            system("cls || clear");
            end1();
            titlu();
            sleep(2);
        }
        //badending
        else
        {
            finishstart();
            dragonhead();
            sleep(1);
            system("cls || clear");
            finish2();
            slow_print("YOU:\nDOES THIS MEAN SHE IS GONE FOREVER?\nPAARTHANAX:\nSHE IS GONE AND NOW YOU'RE NEXT!",us);
            SetConsoleTextAttribute (hConsole, 8);
            dragonmad();
            sleep(1);
            system("cls || clear");
            system("color 0A");
            slow_print("**PAARTHANAX CUT YOU IN HALF IN NO TIME NOT GIVING YOU TIME TO REACT**\n**STRANGELY YOU'RE GETTING KICK OUT OF THE PURGATORY**\n**YOU'RE SEND IN TO A DYING LOOP**",us);
            sleep(1);
            system("cls || clear");
            death();
            end1();
            sleep(2);
        }
        system("cls || clear");
        mersi();
        sleep(1);

        return 0;
}
