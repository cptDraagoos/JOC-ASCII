#ifndef DESENE_H_INCLUDED
#define DESENE_H_INCLUDED

#endif // DESENE_H_INCLUDED

void death();

void dragonatt();

void munti1();

void dragonzbr();

void dragonhead();

void oras();

void slow_print();

void Aela();

void padure();

void tilu();

void cityhall();

void meniu();

void loading();

void barbar();

void youaela();

void tufis();

void minotaur();

void d3();

void doggy();

void sad();

void d4();

void finishstart();

void finish2();

void dragonmad();

void sunstone();

void end1();

void mersi();
